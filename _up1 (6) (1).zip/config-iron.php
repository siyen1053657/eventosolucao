<?php
// ── config-iron.php — Iron Pay Up1 ───────────────────────────

define('IRONPAY_API_TOKEN',    'Qw20i0rZw7nrChJBRfeZMLczoJICC1ogDSk1y1bEIAckxq06RlFfPoMOfQmS');
define('IRONPAY_BASE_URL',     'https://api.ironpayapp.com.br/api/public/v1');
define('IRONPAY_OFFER_HASH',   'lbcqycmwxu');
define('IRONPAY_PRODUCT_HASH', 'gznqnrtxvv');

define('VALOR_CENTAVOS',       2336);        // R$ 23,36
define('VALOR_LABEL',          'R$ 23,36');

define('POSTBACK_URL',   'https://diadosbom.shop/webhook/webhook-ironpay.php');
define('OBRIGADO_URL',   'https://diadosbom.shop/kl/u/up2/');